/*
 * AreaDataContainer.cc
 *
 *  Created on: 10.08.2010
 *      Author: user
 */

#include "AreaDataContainer.h"

AreaDataContainer::AreaDataContainer() {
	// TODO Auto-generated constructor stub

}

AreaDataContainer::~AreaDataContainer() {
	// TODO Auto-generated destructor stub
}
